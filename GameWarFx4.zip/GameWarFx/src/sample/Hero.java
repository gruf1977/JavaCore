package sample;

import java.util.Random;

abstract class Hero {

    protected int health;
    protected String name;
    protected int damage;
    protected int addHeal;
    protected int maxhealth;



    public Hero(int health, String name, int damage, int addHeal) {
        this.health = health;
        this.name = name;
        this.damage = damage;
        this.addHeal = addHeal;
        this.maxhealth = health;
    }
    abstract void hit(Hero hero);

    abstract void healing(Hero hero);

    void causeDamage(int damage) {
        if(health < 0) {
            System.out.println("Герой уже мертвый!");
        } else {
            health -= damage;
        }

    }



    void addHealth(int health) {
        this.health += health;
    }

    public String info() {

        return this.name + " " + (this.health < 0 ? "Герой мертвый" : this.health) + " " + this.damage;

    }

}

class Warrior extends Hero {

    public Warrior(int health, String name, int damage, int addHeal) {
        super(health, name, damage, addHeal);
    }


     @Override
    void hit(Hero hero) {
        if (hero != this) {
            if(health < 0) {
                System.out.println("Герой погиб и бить не может!");
            } else {
                hero.causeDamage(damage);
            }
            // System.out.println(this.name + " нанес урон " + hero.name);
        }
    }

    @Override
    void healing(Hero hero) {
        System.out.println("Войны не умеют лечить!");
    }
}


class Doctor extends Hero {

    public Doctor(int health, String name, int damage, int addHeal) {
        super(health, name, damage, addHeal);
    }


    @Override
    void hit(Hero hero) {
        System.out.println("Доктор не может бить!");
    }

    @Override
    void healing(Hero hero) {
        // System.out.println("------");
        // System.out.println(hero.name + " Здоровье было: " + hero.health);

        if (hero.health>=0 && (hero.health+addHeal)< hero.maxhealth){ //лечим только тех кто еще не умер т.е. здороье больше нуля
            hero.addHealth(addHeal);
        } else if ((hero.health+addHeal)>=hero.maxhealth){ //лечим только до максимального здоровья (не лечим здоровых)

            hero.health = hero.maxhealth;



        }

        //System.out.println(hero.name + " Здоровье стало: " + hero.health);
    }
}



class Assasin extends Hero {

    int cricitalHit;
    Random random = new Random();

    public Assasin(int health, String name, int damage, int addHeal) {
        super(health, name, damage, addHeal);
        this.cricitalHit = random.nextInt(20);
    }

    @Override
    void hit(Hero hero) {
        if (hero != this) {
            if(health < 0) {
                System.out.println("Герой погиб и бить не может!");
            } else {
                hero.causeDamage(damage + cricitalHit);
            }
            // printinarreaLog(this.name + " нанес урон " + hero.name);
            // System.out.println(this.name + " нанес урон " + hero.name);
        }
    }

    @Override
    void healing(Hero hero) {
        System.out.println("Убийцы не умеют лечить!");
    }
}