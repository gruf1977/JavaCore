package sample;

class Hero {

    protected int health;
    protected String name;
    protected int damage;
    protected int addHeal;
    protected int maxhealth;



    public Hero(int health, String name, int damage, int addHeal) {
        this.health = health;
        this.name = name;
        this.damage = damage;
        this.addHeal = addHeal;
        this.maxhealth = health;
    }
    void hit(Hero hero)
    {

    };

    void healing(Hero hero)
    {

    };

    void causeDamage(int damage) {
        if(health < 0) {
            System.out.println("Герой уже мертвый!");
        } else {
            health -= damage;
        }

    }



    void addHealth(int health) {
        this.health += health;
    }

    public String info() {

        return this.name + " " + (this.health < 0 ? "Герой мертвый" : this.health) + " " + this.damage;

    }

    public int getHealth() {
        return health;
    }

    public String getName() {
        return name;
    }

    public int getDamage() {
        return damage;
    }

    public int getAddHeal() {
        return addHeal;
    }
}