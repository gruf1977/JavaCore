package sample;

class Doctor extends Hero {

    public Doctor(int health, String name, int damage, int addHeal) {
        super(health, name, damage, addHeal);
    }


   // @Override
    void hit(Hero hero) {
        System.out.println("Доктор не может бить!");
    }

   // @Override
    void healing(Hero hero) {
       // System.out.println("------");
        // System.out.println(hero.name + " Здоровье было: " + hero.health);

        if (hero.health>=0 && (hero.health+addHeal)< hero.maxhealth){ //лечим только тех кто еще не умер т.е. здороье больше нуля
            hero.addHealth(addHeal);
        } else if ((hero.health+addHeal)>=hero.maxhealth){ //лечим только до максимального здоровья (не лечим здоровых)

            hero.health = hero.maxhealth;



        }

        //System.out.println(hero.name + " Здоровье стало: " + hero.health);
    }
}
