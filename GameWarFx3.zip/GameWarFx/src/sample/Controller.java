package sample;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TextArea;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.Game.*;

import java.util.ArrayList;
import java.util.Random;


public class Controller {

    private ObservableList<Hero> heroData1 = FXCollections.observableArrayList();
    private ObservableList<Hero> heroData2 = FXCollections.observableArrayList();
    private ObservableList<Hero> team1 = FXCollections.observableArrayList();
    private ObservableList<Hero> team2 = FXCollections.observableArrayList();
    @FXML TextField name1;
    @FXML Slider sliderhalth1;
    @FXML Slider sliderdamage1;
    @FXML Slider slideraddhalth1;
    @FXML Label Labelhalf1;
    @FXML Label Labeldamage1;
    @FXML Label LabeldaddHalth1;
    @FXML ComboBox<String> comboType1;
    @FXML TableView tblteam1;
    @FXML TableColumn<Hero, Integer> HealthColumn1;
    @FXML TableColumn<Hero, String> NameColumn1;
    @FXML TableColumn<Hero, Integer> DamageColumn1;
    @FXML TableColumn<Hero, Integer> addHealColumn1;
    public void addWarMen1(){
        if (!name1.getText().equals("")) {
            if (comboType1.getValue().equals("Warrior")) {
                heroData1.add(new Warrior((int) sliderhalth1.getValue(),
                        name1.getText() + "", (int) sliderdamage1.getValue(), 0));
            } else if (comboType1.getValue().equals("Doctor")) {
                heroData1.add(new Doctor((int) sliderhalth1.getValue(),
                        name1.getText() + "", 0, (int) slideraddhalth1.getValue()));

            } else if (comboType1.getValue().equals("Assasin")) {
                heroData1.add(new Assasin((int) sliderhalth1.getValue(),
                        name1.getText() + "", (int) sliderdamage1.getValue(), 0));

            }
            name1.clear();
        } else {

          //  Label3.setText("Введите имя война !");
        }
    }

    public void slideraddhalth1ch(){
        LabeldaddHalth1.setText((int)slideraddhalth1.getValue()+"");
    }
    public void sliderhalth1ch(){
        Labelhalf1.setText((int)sliderhalth1.getValue()+"");
    }

    public void sliderdamage1ch(){
        Labeldamage1.setText((int)sliderdamage1.getValue()+"");
    }
    public void changeScrolParam1(){
        if (comboType1.getValue().equals("Warrior")) {
            sliderhalth1.setMax(300);
            sliderdamage1.setMax(100);
            slideraddhalth1.setMax(0);
            slideraddhalth1.setDisable(true);
            sliderdamage1.setDisable(false);
        } else if (comboType1.getValue().equals("Doctor")) {
            slideraddhalth1.setMax(100);
            sliderdamage1.setMax(0);
            sliderhalth1.setMax(150);
            slideraddhalth1.setDisable(false);
            sliderdamage1.setDisable(true);
        }else if (comboType1.getValue().equals("Assasin")) {
            slideraddhalth1.setMax(0);
            sliderdamage1.setMax(70);
            sliderhalth1.setMax(200);
            slideraddhalth1.setDisable(true);
            sliderdamage1.setDisable(false);
        }
    }


    @FXML TextField name2;
    @FXML Slider sliderhalth2;
    @FXML Slider sliderdamage2;
    @FXML Slider slideraddhalth2;
    @FXML Label Labelhalf2;
    @FXML Label Labeldamage2;
    @FXML Label LabeldaddHalth2;
    @FXML ComboBox<String> comboType2;
    @FXML TableView tblteam2;
    @FXML TableColumn<Hero, Integer> HealthColumn2;
    @FXML TableColumn<Hero, String> NameColumn2;
    @FXML TableColumn<Hero, Integer> DamageColumn2;
    @FXML TableColumn<Hero, Integer> addHealColumn2;
    @FXML TextArea arreaLog;
  //  public static TextArea arreaLog;

    public void addWarMen2(){
        if (!name2.getText().equals("")) {
            if (comboType2.getValue().equals("Warrior")) {
                heroData2.add(new Warrior((int) sliderhalth2.getValue(),
                        name2.getText() + "", (int) sliderdamage2.getValue(), 0));

            } else if (comboType2.getValue().equals("Doctor")) {
                heroData2.add(new Doctor((int) sliderhalth2.getValue(),
                        name2.getText() + "", 0, (int) slideraddhalth2.getValue()));

            } else if (comboType2.getValue().equals("Assasin")) {
                heroData2.add(new Assasin((int) sliderhalth2.getValue(),
                        name2.getText() + "", (int) sliderdamage2.getValue(), 0));

            }
            name2.clear();
        } else {

           // Label3.setText("Введите имя война !");
        }
    }

    public void slideraddhalth2ch(){
        LabeldaddHalth2.setText((int)slideraddhalth2.getValue()+"");
    }
    public void sliderhalth2ch(){
        Labelhalf2.setText((int)sliderhalth2.getValue()+"");
    }

    public void sliderdamage2ch(){
        Labeldamage2.setText((int)sliderdamage2.getValue()+"");
    }
    public void changeScrolParam2(){
        if (comboType2.getValue().equals("Warrior")) {
            sliderhalth2.setMax(300);
            sliderdamage2.setMax(100);
            slideraddhalth2.setMax(0);
            slideraddhalth2.setDisable(true);
            sliderdamage2.setDisable(false);
        } else if (comboType2.getValue().equals("Doctor")) {
            slideraddhalth2.setMax(100);
            sliderdamage2.setMax(0);
            sliderhalth2.setMax(150);
            slideraddhalth2.setDisable(false);
            sliderdamage2.setDisable(true);
        }else if (comboType2.getValue().equals("Assasin")) {
            slideraddhalth2.setMax(0);
            sliderdamage2.setMax(70);
            sliderhalth2.setMax(200);
            slideraddhalth2.setDisable(true);
            sliderdamage2.setDisable(false);
        }
    }



    // инициализируем форму данными
    @FXML
    private void initialize() {
      initData();

        // устанавливаем тип и значение которое должно хранится в колонке

        HealthColumn1.setCellValueFactory(new PropertyValueFactory<Hero, Integer>("Health1"));
        NameColumn1.setCellValueFactory(new PropertyValueFactory<Hero, String>("Name1"));
        DamageColumn1.setCellValueFactory(new PropertyValueFactory<Hero, Integer>("Damage1"));
        addHealColumn1.setCellValueFactory(new PropertyValueFactory<Hero, Integer>("AddHeal1"));

        // заполняем таблицу данными
        tblteam1.setItems(heroData1);

        HealthColumn2.setCellValueFactory(new PropertyValueFactory<Hero, Integer>("Health2"));
        NameColumn2.setCellValueFactory(new PropertyValueFactory<Hero, String>("Name2"));
        DamageColumn2.setCellValueFactory(new PropertyValueFactory<Hero, Integer>("Damage2"));
        addHealColumn2.setCellValueFactory(new PropertyValueFactory<Hero, Integer>("AddHeal2"));

        // заполняем таблицу данными
        tblteam2.setItems(heroData2);

    }

    // подготавливаем данные для таблицы
    // вы можете получать их с базы данных
   private void initData() {
//       arreaLog.appendText("");
       comboType1.getItems().setAll("Warrior", "Assasin", "Doctor");
       comboType1.setValue("Warrior");
       sliderhalth1.setMax(300);
       sliderdamage1.setMax(100);
       slideraddhalth1.setMax(0);
       slideraddhalth1.setDisable(true);
       sliderdamage1.setDisable(false);
       sliderhalth1ch();
       sliderdamage1ch();
       slideraddhalth1ch();
       heroData1.add(new Warrior(290, "Минотавр", 60, 0));
       heroData1.add(new Assasin(160, "Джинкс", 90, 0));
       heroData1.add(new Doctor(110, "Зои", 0, 80));



       comboType2.getItems().setAll("Warrior", "Assasin", "Doctor");
       comboType2.setValue("Warrior");
       sliderhalth2.setMax(300);
       sliderdamage2.setMax(100);
       slideraddhalth2.setMax(0);
       slideraddhalth2.setDisable(true);
       sliderdamage2.setDisable(false);
       sliderhalth2ch();
       sliderdamage2ch();
       slideraddhalth2ch();
       heroData2.add(new Warrior(250, "Тигрил", 50, 0));
       heroData2.add(new Assasin(150, "Акали", 70, 0));
       heroData2.add(new Doctor(120, "Жанна", 0, 60));


    }



    public void StartWarBtn(ActionEvent actionEvent) {
        arreaLog.appendText("Старт игры"+ "\n");
        Random randomStep = new Random();

        team1=heroData1;

        team2 = heroData2;
        boolean tm;
        while (team1.size() > 0 && team2.size() > 0) {
            //  System.out.println("Количество участников team1 = " + team1.size() + " Количество участников team2 = " + team2.size());

            int i,s;
            tm = randomStep.nextBoolean();
            if (tm) {


                i = randomStep.nextInt(team1.size());


                if (team1.get(i) instanceof Doctor) {
                    s = randomStep.nextInt(team1.size());


                    team1.get(i).healing(team1.get(s));
                    printinarreaLog(team1.get(i).name + " Полечил: " + team1.get(s).name);
                    //System.out.println(team1.get(i).name + " Полечил: " + team1.get(s).name);


                } else {
                    if (team2.size() > 0) {
                        int inprot = randomStep.nextInt(team2.size()); // индекс противника

                        team1.get(i).hit(team2.get(inprot));
                        printinarreaLog(team1.get(i).name + " побил " + team2.get(inprot).name);
                        if (team2.get(inprot).health < 0) {
                            printinarreaLog(team2.get(inprot).name + " Мертв Здоровье : " + team2.get(inprot).health);
                            //System.out.println(team2.get(inprot).name + " Мертв Здоровье : " + team2.get(inprot).health);
                            team2.remove(inprot);
                        }
                    } else {
                        break;
                    }
                }


            } else {

                i = randomStep.nextInt(team2.size());

                if (team2.get(i) instanceof Doctor) {
                    s = randomStep.nextInt(team2.size());

                    team2.get(i).healing(team2.get(s));
                    printinarreaLog(team2.get(i).name + " Полечил: " + team2.get(s).name);
                    //System.out.println(team2.get(i).name + " Полечил: " + team2.get(s).name);

                } else {
                    if (team1.size() > 0) {
                        int inprot = randomStep.nextInt(team1.size()); // индекс противника
                        printinarreaLog(team2.get(i).name + " побил " + team1.get(inprot).name);
                       //team2.get(i).hit(team1.get(inprot));
                        if (team1.get(inprot).health < 0) {
                            printinarreaLog(team1.get(inprot).name + " Мертв Здоровье : " + team1.get(inprot).health);
                            //System.out.println(team1.get(inprot).name + " Мертв Здоровье : " + team1.get(inprot).health);
                            team1.remove(inprot);
                        }
                    } else {

                        break;
                    }
                }
                //}
            }

        }
        printinarreaLog("--------__________-------");
        printinarreaLog("Победила команда =" + ((team1.size()>0)?"Team1":"Team2"));
        printinarreaLog("--------победители-------");


       /* System.out.println("--------__________-------");
        System.out.println("Победила команда =" + ((team1.size()>0)?"Team1":"Team2"));
        System.out.println("--------победители-------");*/
        for (Hero t:(team1.size()>0)?team1:team2) {
            printinarreaLog(t.info());
        }
    }

    public void printinarreaLog(String s){

       arreaLog.appendText(s+"\n");

    }

}



