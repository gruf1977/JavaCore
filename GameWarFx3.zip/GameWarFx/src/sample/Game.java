package sample;

import java.util.ArrayList;
import java.util.Random;
class Game {
   public void StartWar() {
        Random randomStep = new Random();


        ArrayList<Hero> team1 = new ArrayList<>();
        team1.add(new Warrior(250, "Тигрил", 50, 0));
        team1.add(new Assasin(150, "Акали", 70, 0));
        team1.add(new Doctor(120, "Жанна", 0, 60));


        ArrayList<Hero> team2 = new ArrayList<>();

        team2.add(new Warrior(290, "Минотавр", 60, 0));
        team2.add(new Assasin(160, "Джинкс", 90, 0));
        team2.add(new Doctor(110, "Зои", 0, 80));

        boolean tm;
        while (team1.size() > 0 && team2.size() > 0) {
          //  System.out.println("Количество участников team1 = " + team1.size() + " Количество участников team2 = " + team2.size());

            int i,s;
            tm = randomStep.nextBoolean();
            if (tm) {


                i = randomStep.nextInt(team1.size());


                if (team1.get(i) instanceof Doctor) {
                    s = randomStep.nextInt(team1.size());


                    team1.get(i).healing(team1.get(s));
                    System.out.println(team1.get(i).name + " Полечил: " + team1.get(s).name);


                } else {
                    if (team2.size() > 0) {
                        int inprot = randomStep.nextInt(team2.size()); // индекс противника
                        team1.get(i).hit(team2.get(inprot));
                        if (team2.get(inprot).health < 0) {
                            System.out.println(team2.get(inprot).name + " Мертв Здоровье : " + team2.get(inprot).health);
                            team2.remove(inprot);
                        }
                    } else {
                        break;
                    }
                }


            } else {

                i = randomStep.nextInt(team2.size());

                if (team2.get(i) instanceof Doctor) {
                    s = randomStep.nextInt(team2.size());

                    team2.get(i).healing(team2.get(s));
                    System.out.println(team2.get(i).name + " Полечил: " + team2.get(s).name);

                } else {
                    if (team1.size() > 0) {
                        int inprot = randomStep.nextInt(team1.size()); // индекс противника
                        team2.get(i).hit(team1.get(inprot));
                        if (team1.get(inprot).health < 0) {
                            System.out.println(team1.get(inprot).name + " Мертв Здоровье : " + team1.get(inprot).health);
                            team1.remove(inprot);
                        }
                    } else {

                        break;
                    }
                }
                //}
            }

        }

        System.out.println("--------__________-------");
        System.out.println("Победила команда =" + ((team1.size()>0)?"Team1":"Team2"));
        System.out.println("--------победители-------");
        for (Hero t:(team1.size()>0)?team1:team2) {
            t.info();
        }
    }

}
